# csc453proj1

Seena Abed, Aladdin Ismael

Usage: schedule [quantum (positive milliseconds)] [program1 [args...]] : [program2 [args...]] ...

Special instructions: N/A. Works as intended.
